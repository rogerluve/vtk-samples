#ifndef vtkDepthOfFieldPassFS_h
#define vtkDepthOfFieldPassFS_h

#include "vtkRenderingOpenGL2Module.h"

VTKRENDERINGOPENGL2_EXPORT extern const char *vtkDepthOfFieldPassFS;

#endif
