#ifndef vtkDepthPeelingPassFinalFS_h
#define vtkDepthPeelingPassFinalFS_h

#include "vtkRenderingOpenGL2Module.h"

VTKRENDERINGOPENGL2_EXPORT extern const char *vtkDepthPeelingPassFinalFS;

#endif
