#ifndef vtkDepthPeelingPassIntermediateFS_h
#define vtkDepthPeelingPassIntermediateFS_h

#include "vtkRenderingOpenGL2Module.h"

VTKRENDERINGOPENGL2_EXPORT extern const char *vtkDepthPeelingPassIntermediateFS;

#endif
