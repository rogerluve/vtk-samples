#ifndef raycastervs_h
#define raycastervs_h

#include "vtkRenderingVolumeOpenGL2Module.h"

VTKRENDERINGVOLUMEOPENGL2_EXPORT extern const char *raycastervs;

#endif
